A TnH character using exclusively shotguns. Because you need more boom tube in your life.

Similar progression to CLL but with recursives replaced with agiles and more panels.

Still WIP - needs better support for mod guns in equipment pools, among other things.

v0.5.0 - init
v0.5.1 - reupload to try to make it appear in game