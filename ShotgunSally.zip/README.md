A TnH character using exclusively shotguns. Because you need more boom tube in your life.

Similar progression to CLL but with recursives replaced with agiles and more panels.

Still WIP - needs better support for mod guns in equipment pools, among many other things.

v0.5.0 - init

v0.5.1 - reupload to try to make it appear in game

v0.6.0 - turns out there's two seperate manifest files?

v0.6.2 - adjustments to pools to hopefully prevent getting wrong attachment/grenade