A TnH character using exclusively shotguns. Because you need more boom tube in your life.

Similar progression to CLL but with recursives replaced with agiles and more panels.

Still WIP - needs better support for mod guns in equipment pools, among many other things. It's my first mod for H3 so having to learn a lot as I go.

v0.5.0 - init

v0.5.1 - reupload to try to make it appear in game

v0.6.0 - turns out there's two seperate manifest files?

v0.6.2 - adjustments to pools to hopefully prevent getting wrong attachment/grenade

v0.7.0 - hopefully corrected an error that prevented required reflex sights from spawning, also changed attachments to be picatinny only due to bespoke/Russian dovetail attachments being next to useless, as well as changing barrel extender to be the mini quad type

v0.8.0 - Changed starting weapon to IZh18 12g Short.\
Opened up equipment pools to make more weapons spawn, hopefully including many mods as well.\
Enumerated break action shop pool to five-ish good options to prevent single shot weapons from spawning, which I consider a stopgap solution and hope to properly fix soon.\
Blacklisted swags because it's supposed to be a difficulty curve not a difficulty flat (and also another variant of that useless 23mm gas shell.)

v1.0.0 - Removed lever actions (small pool and hard to reload), moved tube pumps to their slot and added magfed pumps where tube pumps were.\
Switched enemies to WW2 theme because body armor of any kind makes most shotgun calibers very hard to use. And now they can have flamethrowers, so yeah.\
Added bayonet equipment pool.\
P6-12 now included in magfed automatic pool.\
Removed GroundedFictional ammo type due to swags slipping through. All you really lost is Triple Hit and would you even use that?